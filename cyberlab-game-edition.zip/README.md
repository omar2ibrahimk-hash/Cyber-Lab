# CyberLab Game Edition

A game-like browser interface for CyberLab. This standalone preview demonstrates the intended UX:
- Cyber world map
- Missions and sandbox challenges
- Safe simulated terminal
- XP/progress/achievements/profile
- Responsive phone/desktop UI

The standalone HTML uses demo data. The full V8 backend remains the source for real authentication, PostgreSQL persistence, server-side validation, and production deployment.

Cybersecurity exercises are intentionally fictional/sandboxed and must not be used against real systems.
